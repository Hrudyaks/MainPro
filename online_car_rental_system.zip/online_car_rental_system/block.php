<?php 
include 'dbconnect.php';
$id = $_GET['id'];
if(isset($id))
{
  // Check record exists
  $query = "SELECT id FROM `driverregstr_table` WHERE driverid='$id'";
  $result = mysqli_query($con,$query);
  if ($result->num_rows > 0)
  {
    while($r1=mysqli_fetch_array($result)){
     $id1=$r1['id'];
     $query1 = "SELECT * FROM `login` WHERE id='$id1'";
     $result1 = mysqli_query($con,$query1);
     if($result1)
     {
      $del1 = "UPDATE login SET status=0 WHERE id= '$id1'";
      $res1=mysqli_query($con,$del1);
      if($res1)
      {
        echo '<script type="text/javascript">';
        echo 'alert("User Blocked")';
        echo '</script>';
        echo "<script>setTimeout(\"location.href = '/online_car_rental_system/showdriver.php';\",50);</script>";
      }
     }     
    }
  }
}
?>