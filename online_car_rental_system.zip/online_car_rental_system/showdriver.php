<!DOCTYPE html>
<html>
<head>
<title></title>
<style type="text/css">
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #cc0066;
  color: white;
}
</style>
</head>
<body>
<table id="customers">
  <?php
    include 'dbconnect.php';
    echo "<th>ID</th><th>Full Name</th><th>Email-Id</th><th>House Name</th><th>City Name</th><th>Phone</th><th>License</th><th>Action</th>" ;
    $query="SELECT * FROM `driverregstr_table`,`login` WHERE `driverregstr_table`.id=`login`.id and `login`.status='1'";
    $result = mysqli_query($con,$query) or die(mysqli_error());
    if ($result->num_rows > 0)
    {
      $i=1;
      while($row = $result->fetch_assoc()) 
      {
        echo "<tr><td>".$i."</td><td>".$row["fname"]."</td><td>".$row["email"]."</td><td>".$row["hname"]."</td><td>".$row["cityname"]."</td><td>".$row["phone"]."</td>";?>
        <td><a href="/online_car_rental_system/license/<?php echo $row['license'];?>">View</a></td> 
        <td>
        <a href="block.php?id=<?php echo $row["driverid"]; ?>"><input type='submit' name='submit' value='Block' style="background-color: red;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;">
        </a>
        </td></tr>
        <?php
        ++$i;
      }                    
    }
    else
    {
                        
    }
    $con->close();
    ?>
</table>
<?php
include 'dbconnect.php';
$query="SELECT * FROM `driverregstr_table`,`login` WHERE `driverregstr_table`.id=`login`.id and `login`.status='0'";
$result = mysqli_query($con,$query) or die(mysqli_error());
if ($result->num_rows > 0)
{
  ?>
<table style="margin-top: 80px;" id="customers">
<thead>
  <tr style="text-align: center;">
    <th colspan="8" style="text-align: center;padding: 10px;">Blocked Drivers</th>
  </tr>
</thead>
<th>ID</th><th>Full Name</th><th>Email-Id</th><th>House Name</th><th>City Name</th><th>Phone</th><th>License</th><th>Action</th>
<?php
  $i=1;
  while($row = $result->fetch_assoc()) 
  {
    echo "<tr><td>".$i."</td><td>".$row["fname"]."</td><td>".$row["email"]."</td><td>".$row["hname"]."</td><td>".$row["cityname"]."</td><td>".$row["phone"]."</td>";?>
    <td><a href="/online_car_rental_system/license/<?php echo $row['license'];?>">View</a></td> 
    <td>
    <a href="unblock.php?id=<?php echo $row["driverid"]; ?>"><input type='submit' name='submit' value='Unblock' style="background-color: green;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;">
    </a>
    </td></tr>
    <?php
    ++$i;
  }                        
}
else
{
                        
}
$con->close();
?>
</tbody>
</table>
</body>
</html>