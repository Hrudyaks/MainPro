<!DOCTYPE html>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style type="text/css">
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
label{
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  margin-left:30px;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #cc0066;
  color: white;
}
*body {
  margin: 0;
}

#navbar {
  overflow: hidden;
  background-color: #099;
  position: fixed;
  top: 0;
  width: 100%;
  padding-top: 3px;
  padding-bottom: 3px;
  padding-left: 20px;
}

#navbar a {
  float: left;
  display: block;
  color: #666;
  text-align: center;
  padding-right: 20px;
  text-decoration: none;
  font-size: 17px;
}

#navbar a:hover {
  background-color: #ddd;
  color: black;
}

#navbar a.active {
  background-color: #4CAF50;
  color: white;
}

.main {
  padding: 16px;
  margin-top: 30px;
  width: 100%;
  height: 100vh;
  overflow: auto;
  cursor: grab;
  cursor: -o-grab;
  cursor: -moz-grab;
  cursor: -webkit-grab;
}

.main img {
  height: auto;
  width: 100%;
}

.button {
  width: 300px;
  height: 60px;
}
</style>
</head>
<body>
<table id="customers">
<?php
include 'dbconnect.php';
$ci=$_GET["id"];
$se="select * from cardetails_table where cid='$ci'";
 $r=mysqli_query($con,$se);
?>
<!-- <tr>
<th>No</th><th>Car</th><th>Name</th><th>Amount</th><th>Status</th><th>Action</th>
</tr> -->
<?php
// $i=1;
while($row=mysqli_fetch_array($r))  
{
$cid=$row['cid'];
?>
<tr>
<!-- <td>
    <?php
    // echo $i;
    ?>
</td> -->
<td colspan="2">
  <a href="sample.php" style="padding: 10px;background: green;color: white;">Back</a>
    <?php
   echo '<img src="data:image/jpeg;base64,'.base64_encode($row['pictures'] ).'" style="width:500px;height:300px;margin-left:100px"/>';
   ?>
</td>
</tr>
<tr>
<td>
  <label>Car Name : </label>
</td>
<td style="font-size: 16px;font-weight: 20px"> 
   <?php 
      $dn=$row['carname'];
      $df=$row['model'];
      echo "<b>$dn"."-"."$df</b>";
   ?>
  </td>
</tr>
<tr>
  <td>
    <label>Number of Seats : </label>
  </td>
  <td>
    <?php
    echo $row['seat'];
    ?>
  </td>
</tr>
<tr>
  <td>
    <label>A/C : </label>
  </td>
  <td>
    <?php
    echo $row['ac'];
    ?>
  </td>
</tr>
<tr>
  <td>
    <label>Fuel : </label>
  </td>
  <td>
    <?php
    echo $row['fueltype'];
    ?>
  </td>
</tr>
<tr>
  <td>
    <label>Mileage : </label>
  </td>
  <td>
    <?php
    echo $row['mileage'];
    ?>
  </td>
</tr>
<tr>
  <td>
    <label>Amount : </label>
  </td>
  <td>
    <?php
    echo $row['price'];
    ?>
  </td>
</tr>
<tr>
  <td colspan="2">
    <a href="cblock.php?id=<?php echo $cid;?>"><input type='submit' name='submit' value='Block' style="width:100%;background-color: red;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;">
    </a>
  </td>
</tr>
<?php
// ++$i;
}
?>
</table>
</body>
</html>