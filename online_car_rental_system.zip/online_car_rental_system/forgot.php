<?php
include 'dbconnect.php';
$Generator = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
$j = substr(str_shuffle($Generator),0,10);
	if (isset($_POST['submit'])) {
		$email=$_POST['email'];
		$mail1=md5($j);
        $connected = @fsockopen("www.google.com", 80); 
                                        //website, port  (try 80 or 443)
    if ($connected){
        echo"true"; //action when connected
        fclose($connected);
    }else{
        echo"false"; //action in connection failure
    }
        $sql="select * from login where email='$email'";
            $result=mysqli_query($con,$sql);
            $rowcount=mysqli_num_rows($result);
            if($rowcount!=0){
		$q="update login set password='$mail1' where email='$email'";
		mysqli_query($con,$q);
        require 'phpmailer/PHPMailerAutoload.php';
//require 'credential.php';

$mail = new PHPMailer;

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com;';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'hrudya148@gmail.com';                 // SMTP username
$mail->Password = 'hru12345';                           // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                    // TCP port to connect to

$mail->setFrom('hrudya148@gmail.com', 'Online car rental system');
$mail->addAddress($email);     // Add a recipient
$mail->addReplyTo('hrudya148@gmail.com');
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'Reset Password';
$mail->Body = "<p style='font-size:16px;'>Your new password for your account is <b>$j</b></p>";
//$mail->AltBody = $_POST['msg'];

            if(!$mail->send()) {
                echo "<script>alert('Something went wrong')</script>";
            } else {
                echo "<script>alert('Please check your mail')</script>";
            ?>
            <script>
    	       window.location="index.php";
            </script>
            <?php
            }
            }
            else
            {
                echo"<script>alert('Not an existing email');</script>";
                ?>
            <script>
               window.location="forgo.php";
            </script>
            <?php
            }

        }
            ?>