<!DOCTYPE html>
<html>
<head>
<title></title>
<style type="text/css">
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #cc0066;
  color: white;
}
</style>
</head>
<body>
<table id="customers">
<?php
include 'dbconnect.php';
$q1="select * from booking_table,userrgstr_table where userrgstr_table.userid=booking_table.userid";
$s1=mysqli_query($con,$q1);
$rowcount=mysqli_num_rows($s1);
if($rowcount>0)
{
  echo "<th>Slno</th><th>Customer Name</th><th>Driver Name</th><th>Car Name</th><th>Date From</th><th>Date To</th><th>Amount</th>" ;
  $i=1;
  while($r1=mysqli_fetch_array($s1)){
    $li=$r1['bid'];
    $uid=$r1['userid'];
    $did=$r1['driverid'];
    $fname=$r1['fname'];
    $amt=$r1['amount'];
    $df=$r1['dfrom'];
    $dt=$r1['dto']; 
    $ci=$r1['cid'];             
    $q2="select * from cardetails_table where cid='$ci'";
    $s2=mysqli_query($con,$q2);
    while ($r2=mysqli_fetch_array($s2)) 
    {
      $id2=$r2['carname'];
      $dd=$r2['model'];
      $q3="select * from driverregstr_table where driverregstr_table.driverid='$did'";
      $s3=mysqli_query($con,$q3);
      $r3=mysqli_fetch_array($s3); 
        if($did==NULL)
        {
          $dn='Pending';
        }  
        else
        {
          $dn=$r3['fname'];
        }
      echo"<tr><td>$i</td><td>$fname</td><td>$dn</td><td>$id2"."-"."$dd</td><td>$df</td><td>$dt</td><td>$amt</td></tr>";
          ++$i;
    }           
  }
}
else
{
  echo"<h4 style='margin-left:350px;margin-top:50px'>No Records Found!!</h2>";
}
?>
</table>
</body>
</html>