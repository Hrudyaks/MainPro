<!DOCTYPE html>
<html>
<head>
<style>
* {
  box-sizing: border-box;
}

input[type=text],input[type=email], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
   width: 100%;
  background-color: #cc0066;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #99004d;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
.error{
  color: #F00;
  background-color: #FFF;
        }
</style>
</head>
<body>

<div class="container" style="margin-right: 150px;margin-left: 150px;">
  <form action="#" id="reg" method="post" class="adminpro-form" enctype="multipart/form-data">
  <div class="row">
    <div class="col-25">
      <label>Model</label>
    </div>
    <div class="col-75">                                          
      <input type="text" name="model" placeholder="Model..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>Registration Number</label>
    </div>
    <div class="col-75">
      <input type="text" name="regno" placeholder="Registration number.." />
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>Name</label>
    </div>
    <div class="col-75">
      <input type="text" name="cname" placeholder="Car name.." />
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>A/C</label>
    </div>
    <div class="col-75" style="margin-top: 15px">
      <input type="radio" name="ac" value="yes" checked="checked">Yes                              
      <input type="radio" name="ac" value="no">No
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>Fuel Type</label>
    </div>
    <div class="col-75">
      <select id="dist" name="dist">
        <option value="">Select Fuel</option>
        <option value="petrol">Petrol</option>
        <option value="diesel">Diesel</option>
      </select>
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>Seats</label>
    </div>
    <div class="col-75">
      <input type="text" name="seat" placeholder="Number of seats">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>Mileage</label>
    </div>
    <div class="col-75">
      <input type="text" name="mileage" placeholder="Mileage..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>Pictures</label>
    </div>
    <div class="col-75" style="margin-top: 15px">
      <input type="file" name="image" placeholder="Select picture..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>Price</label>
    </div>
    <div class="col-75">
      <input type="text" name="price" placeholder="Price.." />
    </div>
  </div>
  <div class="row">
    <input type="submit" value="Register" name="submit" style="font-size: 14px">
  </div>
    <?php
    include 'dbconnect.php'; 
    if(isset($_POST['submit']))
    {
     $model=$_POST['model'];
     $name=$_POST['cname'];
     $ac=$_POST['ac'];
     $fuel=$_POST['fuel'];
     $seat=$_POST['seat'];
     $mileage=$_POST['mileage'];
     $regno=$_POST['regno'];
     $fil=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
     $price=$_POST['price'];
     $sql="INSERT INTO `cardetails_table`(`model`, `regno`, `carname`, `seat`, `ac`, `fueltype`, `mileage`, `pictures`, `price`, `status`) VALUES ('$model','$regno','$name','$seat','$ac','$fuel','$mileage','$fil','$price','available')";
     $ch=mysqli_query($con,$sql);
     if($ch)
     {
    ?>
	    <script>
	    alert("Registered  Successfully");
	    window.location="addcar.php";
	    </script>
    <?php
    }
    else
    {
       echo"<script>alert('Car already exists');</script>";
    }
    }
    mysqli_close($con);
    ?>
  </form>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/3.3.1/jquery-ui.min.js" ></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
jQuery.validator.addMethod("noSpace", function(value, element) { 
    return value == '' || value.trim().length != 0;  
}, "No space please and don't leave it empty");
jQuery.validator.addMethod("customEmail", function(value, element) { 
  return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test( value ); 
}, "Please enter valid email address!");
jQuery.validator.addMethod("accept", function(value, element, param) {
     return value.match(new RegExp("." + param + "$"));
   },"Invalid Format");
$.validator.addMethod("alphabetsnspace", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    });
jQuery.validator.addMethod("seatnum", function(value, element) { 
  return this.optional( element ) || /^([1-9])+$/.test( value ); 
}, "Please enter valid seat number!");
jQuery.validator.addMethod("seatvalid", function(value, element) { 
  return value >= 4; 
}, "Please enter valid seat number!");
$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, numbers, and underscores only please" );
var $userreg = $('#reg');
if($userreg.length){
  $userreg.validate({
    errorClass: 'errors',
      rules:{
          //username is the name of the textbox
          model: {
              required: true,
              alphanumeric:true
          },
          regno: {
              required: true,
              alphanumeric:true,
              minlength: 9,
              maxlength: 9
          },
          cname: {
              required: true
          },
          ac: {
              required: true
          },
          fuel: {
               required:true
                },
          seat:{
              required: true,
              number: true,
              seatnum:true,
              seatvalid:true,
              minlength: 1,
              maxlength: 1
            },
           mileage:{
              required: true,
              number: true,
              minlength: 2,
              maxlength: 2
            },
          image: {
              required: true,
              accept: "(jpg?|jpeg|png)"
          },
          price: {
              required: true,
              number: true,
              minlength: 3,
              maxlength: 5
          } 
      },
      messages:{
          model: {
              //error message for the required field
              required: 'Please enter model!'
          },
          regno: {
              //error message for the required field
              required: 'Please enter registration number!'
          },
          cname: {
              //error message for the required field
              required: 'Please enter car name!'
          },
           ac: {
              //error message for the required field
              required: 'Please select an option!'
          },
          fuel:{
              required:'Mandatory field'
          },
           seat:{
              required: 'Mandatory field',
              number: 'Please enter only numbers'
            },
          mileage:{
              required: 'Mandatory field',
              number: 'Please enter only numbers'
            },
          
          image: {
              required: 'Please select picture!'
          },
          price: {
              required: 'Please enter price!',
              number: 'Please enter only numbers'
          }, 
      },
      
  highlight: function (element) {
                $(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            }
  });
}
  </script> 
</body>
</html>
