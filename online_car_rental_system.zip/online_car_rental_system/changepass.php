<?php
session_start();
if(isset($_SESSION['loginid'])){
include('dbconnect.php');
$id=$_SESSION['loginid'];
$mail=$_SESSION['mail'];
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Online Car Rental System</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'>
        </script>
	<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
	<script src="validate.js"></script>
  <style type="text/css">
        .error{
  color: #F00;
  background-color: #FFF;
        }
    </style>
</head>

<body style="background-image:url(images/bg_2.jpg); background-repeat:no-repeat; background-size:cover">
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>
<div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="dashboardphp.php" class="nav-link">Back</a></li>
	        </ul>
	      </div>
		   </div>
	  </nav>
	  <div class="container">
        <div class="row no-gutters slider-text justify-content-center align-items-center">
  <div class="col-lg-4 col-md-6 mt-0 mt-md-5 d-flex">
     
           	<form action="#" method="post" name="form1" id="reg" class="request-form ftco-animate" autocomplete="off">
						<div class="">
          		<h2 align="center" style="color:#FF6600">Change Password</h2>
						</div>
						<div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label">EmailId</label>
							</div>
							<div class="form-group ml-2">
	    					<input type="text" name="email" class="form-control" value="<?php echo"$mail";?>" placeholder="Full name" readonly>
							</div>
	    				</div>
	    				<div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label">New Password</label>
							</div>
							<div class="form-group ml-2">
	    					<input type="password" name="pass" class="form-control" placeholder="password">
							</div>
	    				</div>
						<div class="d-flex">
	    					<div class="form-group mr-2">
	                		<label for="" class="label">Retype Password</label>
							</div>
							<div class="form-group ml-2">
	                		<input type="password" name="rpass" class="form-control" placeholder="confirm password">
							</div>
	              		</div>
	            		<div class="group" align="center">
	              			<input type="submit" name="submit" align="middle" value="Change" class="btn btn-primary py-3 px-4">
	            		</div>
   			</form>
			</div>
<?php
include "dbconnect.php";
   
if(isset($_POST['submit']))
{
$uname= $_POST["email"];
$new1= $_POST["pass"];
$new=md5($new1);
$conf=$_POST["rpass"];
$re= mysqli_query($con,"select * from login where email='$uname'");


if(mysqli_num_rows($re)>0)
{
  
  if ($new1==$conf)
  { 
  mysqli_query($con,"update login set password='$new' where email='$uname'");
  ?>
    <script>
    alert("successfully updated");
    </script>
    <?php
  }
  else
  {
    ?>
    <script>
    alert("Password MisMatch");
    </script>
  
<?php
  }
}
else
{
  
  ?>
    
    <script>
  alert("Password Does not exists");
  </script>    
    <?php }
}?>

          </div>
		     <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>
  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script> 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/3.3.1/jquery-ui.min.js" ></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
    jQuery.validator.addMethod("noSpace", function(value, element) { 
    return value == '' || value.trim().length != 0;  
}, "No space please and don't leave it empty");
jQuery.validator.addMethod("customEmail", function(value, element) { 
  return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test( value ); 
}, "Please enter valid email address!");

$.validator.addMethod("alphabetsnspace", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    });
$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, numbers, and underscores only please" );
var $userreg = $('#reg');
if($userreg.length){
  $userreg.validate({
    errorClass: 'errors',
      rules:{
          email: {
              required: true,
              customEmail: true
          },
          pass: {
              required: true,
              minlength:8
			  
          },
          rpass: {
              required: true,
              equalTo: '[name="pass"]'
          }
      },
      messages:{
          email: {
              required: 'Please enter email!',
              //error message for the email field
              email: 'Please enter valid email!'
          },
          pass: {
              required: 'Please enter password!',
              minlength:'Please enter atleast 8 length password!'
          },
          rpass: {
              required: 'Please enter confirm password!',
              equalTo: 'Please enter same password!'
          },
         
          
          
      },
     highlight: function (element) {
                $(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            }
  });
}
  </script>	
</body>
</html>
