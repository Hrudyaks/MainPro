<!DOCTYPE html>
<html>
<head>
	<title>mail</title>
</head>
<body>
<form method="POST" id="mail" action="">
	<label>To Mail:</label>
	<input type="text" name="tmail">
	<br/>
	<label>Subject:</label>
	<input type="text" name="sub">
	<br/>
	<label>Message:</label>
	<textarea name="msg"></textarea>
	<br/>
	<input type="submit" name="submit">
	<?php
	if (isset($_POST['submit'])) {
require 'phpmailer/PHPMailerAutoload.php';
require 'credential.php';

$mail = new PHPMailer;

//$mail->SMTPDebug = 4;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com;';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'hrudya148@gmail.com';                 // SMTP username
$mail->Password = 'hru12345';                           // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                    // TCP port to connect to

$mail->setFrom('hrudya148@gmail.com', 'Online car rental system');
$mail->addAddress($_POST['tmail']);     // Add a recipient
//$mail->addAddress('ellen@example.com');               // Name is optional
$mail->addReplyTo('hrudya148@gmail.com');
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');

//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = $_POST['sub'];
$mail->Body    = 'This is the HTML message body <b>in bold!</b>';
$mail->AltBody = $_POST['msg'];

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';
}
}
?>
</form>
</body>
</html>