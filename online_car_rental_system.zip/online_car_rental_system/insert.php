<?php

//insert.php

include('dbconnect.php');

if(count($_FILES["image"]["tmp_name"]) > 0)
{
 for($count = 0; $count < count($_FILES["image"]["tmp_name"]); $count++)
 {
  $image_file = addslashes(file_get_contents($_FILES["image"]["tmp_name"][$count]));
  $query = "INSERT INTO images(cid,image) VALUES ('1','$image_file')";
  $statement = $con->prepare($query);
  $statement->execute();
 }
}