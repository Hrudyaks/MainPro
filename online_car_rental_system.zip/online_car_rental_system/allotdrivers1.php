<!DOCTYPE html>
<html>
<head>
<title></title>
<style type="text/css">
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #cc0066;
  color: white;
}
</style>
</head>
<body>
<table id="customers">
 <?php
              include 'dbconnect.php';
              $da=date('y/m/d');
              $q1="select * from booking_table,userrgstr_table where userrgstr_table.userid=booking_table.userid and booking_table.driver='yes' and driverid IS NULL and dfrom>='$da'";
              $s1=mysqli_query($con,$q1);
              $rowcount=mysqli_num_rows($s1);
              if($rowcount>0)
              {
              echo "<th>Slno.</th><th>Full Name</th><th>Car Name</th><th>Date From</th><th>Date To</th><th>Amount</th><th>Action</th>" ;
              $i=1;
              while($r1=mysqli_fetch_array($s1)){
                $li=$r1['bid'];
                $uid=$r1['userid'];
                $fname=$r1['fname'];
                $amt=$r1['amount'];
                $df=$r1['dfrom'];
                $dt=$r1['dto'];              
                $q2="select * from cardetails_table,booking_table where cardetails_table.cid=booking_table.cid and booking_table.userid='$uid' and booking_table.bid='$li'";
                $s2=mysqli_query($con,$q2);
                
                while ($r2=mysqli_fetch_array($s2)) {
                  $id2=$r2['carname'];  
                  $dd=$r2['model'];
                  echo"<tr><td>$i</td><td>$fname</td><td>$id2"."-"."$dd</td><td>$df</td><td>$dt</td><td>$amt</td>";
                  ?>
                  <td>
                    <?php echo"<a href=allocate.php?id=$li><input type='submit' name='submit' value='Allocate' style='background-color: red;color: white;padding:10px;'>"?>
</a>
                  </td>
                    <?php
                    $i++;
                }
              }
          }
          else
          {
            echo"<h4 style='margin-left:350px;margin-top:50px'>No Records Found!!</h2>";
          }
            ?>
                                        </table>
</body>
</html>