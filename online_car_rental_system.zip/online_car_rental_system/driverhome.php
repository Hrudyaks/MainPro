<?php
session_start();
if(isset($_SESSION['loginid'])){
include('dbconnect.php');
$lid=$_SESSION['loginid'];
$s="select * from driverregstr_table where id='$lid'";
$t=mysqli_query($con,$s);
$u=mysqli_fetch_array($t);
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Dashboard v.1.0 | Adminpro - Admin Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
		============================================ -->
    <link rel="shortcut icon" type="material-design/image/x-icon" href="img/favicon.ico">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/bootstrap.min.css">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/font-awesome.min.css">
    <!-- adminpro icon CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/adminpro-custon-icon.css">
    <!-- meanmenu icon CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/meanmenu.min.css">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/jquery.mCustomScrollbar.min.css">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/animate.css">
    <!-- data-table CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="material-design/css/data-table/bootstrap-editable.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/normalize.css">
    <!-- charts C3 CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/c3.min.css">
    <!-- forms CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/form/all-type-forms.css">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/style.css">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/responsive.css">
    <!-- modernizr JS
		============================================ -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body class="materialdesign">
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <!-- Header top area start-->
    <div class="wrapper-pro">
        <div class="left-sidebar-pro">
            <nav id="sidebar">
                <div class="sidebar-header">
                    <a href="driverhome.php"><img src="images/download.jpg" alt="" />
                    </a>
                    <h3><?php echo $u['fname'];?></h3>
                </div>
                <div class="left-custom-menu-adp-wrap">
                    <ul class="nav navbar-nav left-sidebar-menu-pro">
                        <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"> <span class="mini-dn">View</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                            <div role="menu" class="dropdown-menu left-menu-dropdown animated flipInX">
                                <a href="#" id="vbook" class="dropdown-item">View Bookings</a>
                            </div>
                        </li>
                        <li class="nav-item"><a href="#" id="edpro" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"> <span class="mini-dn">Edit Profile</span></a>
                        </li>
                        <li class="nav-item"><a href="#" id="apply" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"> <span class="mini-dn">Apply Leave</span></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <div class="content-inner-all">
            <div class="header-top-area">
                <div class="fixed-header-top">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-1 col-md-6 col-sm-6 col-xs-12">
                                <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
                                    <i class="fa fa-bars"></i>
                                </button>
                                <div class="admin-logo logo-wrap-pro">
                                    <a href="#"><img src="img/logo/log.png" alt="" />
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-1 col-sm-1 col-xs-12">
                                
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                <div class="header-right-info">
                                    <ul class="nav navbar-nav mai-top-nav header-right-menu">
                                        <li class="nav-item">
                                            <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                                <span class="adminpro-icon adminpro-user-rounded header-riht-inf"></span>
                                                <span class="admin-name"><?php echo $u['fname'];?></span>
                                                <span class="author-project-icon adminpro-icon adminpro-down-arrow"></span>
                                            </a>
                                            <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated flipInX">
                                                <!--<li><a href="#"><span class="adminpro-icon adminpro-user-rounded author-log-ic"></span>Edit Profile</a>
                                                </li>-->
                                                <li><a href="#" id="change"><span class="adminpro-icon adminpro-home-admin author-log-ic"></span>Change Password</a>
                                                </li>
                                                <li><a href="logout.php"><span class="adminpro-icon adminpro-locked author-log-ic"></span>Log Out</a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Header top area end-->
            <!-- Breadcome start-->
            
            <!-- Breadcome End-->
            <!-- Mobile Menu start -->
            
            <!-- Mobile Menu end -->
            <!-- Breadcome start-->
            <div class="breadcome-area mg-b-30 small-dn">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                        
                            <div class="breadcome-list map-mg-t-40-gl shadow-reset">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <div class="breadcome-heading">
                                            <h1 style="color: #333399;margin-left: 25px">Welcome <?php echo $u['fname'];?></h1>
                                            <iframe id="iloadspace" STYLE="width:170%;height:620px;margin-left:90px;margin-top:10px;" FRAMEBORDER="no" BORDER="0"  seamless="seamless" ></iframe>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Breadcome End-->
            <!-- welcome Project, sale area start-->
            <!-- Data table area End-->
        </div>
    </div>
    <!-- Footer Start-->
    
    <!-- Footer End-->
    <!-- Chat Box Start-->
    
    <!-- Chat Box End-->
    <!-- jquery
		============================================ -->
    <script src="material-design/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="material-design/js/bootstrap.min.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="material-design/js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="material-design/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="material-design/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="material-design/js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
		============================================ -->
    <script src="material-design/js/counterup/jquery.counterup.min.js"></script>
    <script src="material-design/js/counterup/waypoints.min.js"></script>
    <script src="material-design/js/counterup/counterup-active.js"></script>
    <!-- peity JS
		============================================ -->
    <script src="material-design/js/peity/jquery.peity.min.js"></script>
    <script src="material-design/js/peity/peity-active.js"></script>
    <!-- sparkline JS
		============================================ -->
    <script src="material-design/js/sparkline/jquery.sparkline.min.js"></script>
    <script src="material-design/js/sparkline/sparkline-active.js"></script>
    <!-- flot JS
		============================================ -->
    <script src="material-design/js/flot/jquery.flot.js"></script>
    <script src="material-design/js/flot/jquery.flot.tooltip.min.js"></script>
    <script src="material-design/js/flot/jquery.flot.spline.js"></script>
    <script src="material-design/js/flot/jquery.flot.resize.js"></script>
    <script src="material-design/js/flot/jquery.flot.pie.js"></script>
    <script src="material-design/js/flot/Chart.min.js"></script>
    <script src="material-design/js/flot/flot-active.js"></script>
    <!-- map JS
		============================================ -->
    <script src="material-design/js/map/raphael.min.js"></script>
    <script src="material-design/js/map/jquery.mapael.js"></script>
    <script src="material-design/js/map/france_departments.js"></script>
    <script src="material-design/js/map/world_countries.js"></script>
    <script src="material-design/js/map/usa_states.js"></script>
    <script src="material-design/js/map/map-active.js"></script>
    <!-- data table JS
		============================================ -->
    <script src="material-design/js/data-table/bootstrap-table.js"></script>
    <script src="material-design/js/data-table/tableExport.js"></script>
    <script src="material-design/js/data-table/data-table-active.js"></script>
    <script src="material-design/js/data-table/data-table-active.js"></script>
    <script src="material-design/js/data-table/data-table-active.js"></script>
    <script src="material-design/js/data-table/bootstrap-table-editable.js"></script>
    <script src="material-design/js/data-table/bootstrap-editable.js"></script>
    <script src="material-design/js/data-table/bootstrap-table-resizable.js"></script>
    <script src="material-design/js/data-table/colResizable-1.5.source.js"></script>
    <script src="material-design/js/data-table/bootstrap-table-export.js"></script>
    <!-- main JS
		============================================ -->
    <script src="material-design/js/main.js"></script>
    <script>
$(document).ready(function(){
  
  $('#vbook').click(function () { 
    
          $('.breadcome-heading h1').contents().replaceWith('Bookings');
          $('#iloadspace').attr('src','bookings.php');
           });
  $('#edpro').click(function () { 
    
          $('.breadcome-heading h1').contents().replaceWith('Edit Profile');
          $('#iloadspace').attr('src','editprodriv.php');
           });
  $('#change').click(function () { 
    
          $('.breadcome-heading h1').contents().replaceWith('Change Password');
          $('#iloadspace').attr('src','changepass2.php');
           });
          
  $('#use').click(function () { 
    
        $('.breadcome-heading h1').contents().replaceWith('Users');
          $('#iloadspace').attr('src','showuser.php');
           });

   $('#sdriv').click(function () { 
    
    $('.breadcome-heading h1').contents().replaceWith('Drivers');
    $('#iloadspace').attr('src','showdriver.php');
     });

     $('#srent').click(function () { 
    $('.breadcome-heading h1').contents().replaceWith('Rents');
    $('#iloadspace').attr('src','showrents.php');
     });

    $('#feed').click(function () { 
    $('.breadcome-heading h1').contents().replaceWith('Feedbacks');
    $('#iloadspace').attr('src','showfeedbacks.php');
     });

    $('#scar').click(function () { 
    $('.breadcome-heading h1').contents().replaceWith('Cars');
    $('#iloadspace').attr('src','sample.php');
     });

     $('#alot').click(function () { 
    $('.breadcome-heading h1').contents().replaceWith('Allocate');
    $('#iloadspace').attr('src','allotdrivers1.php');
     });

      });
            
            
   

           
  

                  
</script>
</body>

</html>
<?php
}
else
{
  echo"<script>window.location.href='index.php';</script>";
}
?>