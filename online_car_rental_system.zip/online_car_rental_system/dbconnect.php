<?php
$con=mysqli_connect("localhost","root","","online_car_rental_system")or die("unable to connect");
?>