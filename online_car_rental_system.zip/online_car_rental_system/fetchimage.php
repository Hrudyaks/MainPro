<?php

//fetch_images.php

include('dbconnection.php');

$query = "SELECT * FROM images ORDER BY imgid DESC";

$statement = $connect->prepare($query);

if($statement->execute())
{
 $result = $statement->fetchAll();
 foreach($result as $row)
 {
  echo '
   <img class="mySlides" src="data:image/jpeg;base64,'.base64_encode($row['image'] ).'"  style="width:50%"/>
  ';
 }
}
?>
<button class="w3-button w3-black w3-display-left" onclick="plusDivs(-1)">&#10094;</button>
<button class="w3-button w3-black w3-display-right" onclick="plusDivs(1)">&#10095;</button>