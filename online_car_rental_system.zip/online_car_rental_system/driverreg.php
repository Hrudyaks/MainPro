<!DOCTYPE html>
<html>
<head>
<style>
* {
  box-sizing: border-box;
}

input[type=text],input[type=email], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
   width: 100%;
  background-color: #cc0066;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #99004d;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
.error{
  color: #F00;
  background-color: #FFF;
        }
</style>
</head>
<body>

<div class="container" style="margin-right: 150px;margin-left: 150px;">
  <form action="#" id="reg" method="post" class="adminpro-form" enctype="multipart/form-data">
  <div class="row">
    <div class="col-25">
      <label>Full Name</label>
    </div>
    <div class="col-75">
      <input type="text" id="fname" name="fname" placeholder="Your name..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>Gender</label>
    </div>
    <div class="col-75" style="margin-top: 15px">
      <input type="radio" name="gender" value="Male" checked="checked">Male                              
    <input type="radio" name="gender" value="Female">Female
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>Age</label>
    </div>
    <div class="col-75">
      <input type="text" name="age" placeholder="Your age..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>District</label>
    </div>
    <div class="col-75">
      <select id="dist" name="dist">
        <option value="">Select District</option>
        <?php 
        include 'dbconnect.php'; 
        $q1="select * from district";
        $ch1=mysqli_query($con,$q1);
        while($data=mysqli_fetch_array($ch1))
        {
          $d1=$data['districtid'];
          echo "<option value=$d1>"; echo $data["distname"];
        } 
        echo "</option>";
      ?>
      </select>
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>City Name</label>
    </div>
    <div class="col-75">
      <input type="text" name="cname" placeholder="Your city name..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>House Name</label>
    </div>
    <div class="col-75">
      <input type="text" name="hname" placeholder="Your house name..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>Pin Code</label>
    </div>
    <div class="col-75">
      <input type="text" name="pncode" placeholder="Your pin code..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>Phone</label>
    </div>
    <div class="col-75">
      <input type="text" name="phone" placeholder="Your phone number..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>License</label>
    </div>
    <div class="col-75" style="margin-top: 15px">
      <input type="file" name="image" placeholder="Your license..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label>Email Id</label>
    </div>
    <div class="col-75">
      <input type="email" name="email" placeholder="Your email-id..">
    </div>
  </div>
  <div class="row">
    <input type="submit" value="Register" name="submit" style="font-size: 14px">
  </div>
  <?php 
            include 'dbconnect.php'; 
            if(isset($_POST['submit']))
            {
            $Generator = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            $j = substr(str_shuffle($Generator),0,10);
            $fnam=$_POST['fname'];
            $gen=$_POST['gender'];
            $age=$_POST['age'];
            $dist=$_POST['dist'];
            $cnam=$_POST['cname'];
            $hnam=$_POST['hname'];
            $pin=$_POST['pncode'];
            $phon=$_POST['phone'];
            $email=$_POST['email'];
            $pass=md5($j);    
            $q="select id from login where email='$email'";
            $r1=mysqli_query($con,$q);
            $re=mysqli_fetch_array($r1,MYSQLI_ASSOC);
            $iid=$re['id'];
            if($iid!="")
            {
            echo"<script>alert('Already exists with this email');</script>";
            }
            else
            {
            $sq="insert into login(`email`,`password`,`type`,`status`)values('$email','$pass',2,1)";
            if(mysqli_query($con,$sq))
            {
                $s=mysqli_query($con,"select id from login where email='$email'");
                $r=mysqli_fetch_array($s,MYSQLI_ASSOC);
                $lid=$r['id'];
                $dir='license/';
                $tfile=$_FILES['image']['name'];
                $target_file=$dir.basename($_FILES['image']['name']);
                move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
                $sql="insert into driverregstr_table(`id`,`fname`,`gender`,`age`,`districtid`,`cityname`,`hname`,`pin`,`phone`,`license`,`status`)values('$lid','$fnam','$gen','$age','$dist','$cnam','$hnam','$pin','$phon','$tfile','Available')";
                $ch=mysqli_query($con,$sql);
                if($ch)
                {
                ?>
                <script>
                alert("Registered  Successfully");
                window.location="driverreg1.php";
                </script>
                <?php
                require 'phpmailer/PHPMailerAutoload.php';

                $mail = new PHPMailer;

                $mail->isSMTP();                                      // Set mailer to use SMTP
                $mail->Host = 'smtp.gmail.com;';  // Specify main and backup SMTP servers
                $mail->SMTPAuth = true;                               // Enable SMTP authentication
                $mail->Username = 'hrudya148@gmail.com';                 // SMTP username
                $mail->Password = 'hru12345';                           // SMTP password
                $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
                $mail->Port = 587;                                    // TCP port to connect to

                $mail->setFrom('hrudya148@gmail.com', 'Online car rental system');
                $mail->addAddress($email);     // Add a recipient
                $mail->addReplyTo('hrudya148@gmail.com');
                $mail->isHTML(true);                                  // Set email format to HTML

                $mail->Subject = 'Confirmation Mail';
                $mail->Body    = 'Hello '.$fnam.', password for your account is <b>'.$j.'</b>';
                //$mail->AltBody = $_POST['msg'];       

                if(!$mail->send()) {
                echo "<script>alert('Something went wrong.')</script>";
                } else {
                echo "<script>alert('Mail send successfully.')</script>";
                }
                }
                else
                {
                echo"error:".$sql."<br>".mysqli_error($con);
                }
                }
                }
                }
                mysqli_close($con);
                ?>
  </form>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/3.3.1/jquery-ui.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script>
jQuery.validator.addMethod("noSpace", function(value, element) { 
    return value == '' || value.trim().length != 0;  
}, "No space please and don't leave it empty");
jQuery.validator.addMethod("customEmail", function(value, element) { 
  return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test( value ); 
}, "Please enter valid email address!");
jQuery.validator.addMethod("accept", function(value, element, param) {
     return value.match(new RegExp("." + param + "$"));
   },"Invalid Format");
jQuery.validator.addMethod("phonenum", function(value, element) { 
  return this.optional( element ) || /^([6-9_\.\-])+(([0-9]))+$/.test( value ); 
}, "Please enter valid phone number!");
jQuery.validator.addMethod("pin", function(value, element) { 
  return this.optional( element ) || /^([1-9_\.\-])+(([0-9]))+$/.test( value ); 
}, "Please enter valid pincode!");
$.validator.addMethod("alphabetsnspace", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    });
$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, numbers, and underscores only please" );
jQuery.validator.addMethod("agevalid", function(value, element) { 
  return value >= 18; 
}, "Please enter valid age!");
jQuery.validator.addMethod("aglid", function(value, element) { 
  return value <= 80; 
}, "Please enter valid age!");
var $userreg = $('#reg');
if($userreg.length){
  $userreg.validate({
    errorClass: 'errors',
      rules:{
          //username is the name of the textbox
          fname: {
              required: true,
              alphabetsnspace: true,
              noSpace:true,
              minlength:5
              //alphanumeric is the custom method, we defined in the above
              
          },
          cname: {
              required: true,
              alphabetsnspace: true,
              noSpace:true
              //alphanumeric is the custom method, we defined in the above
              
          },
          hname: {
              required: true,
              alphabetsnspace: true,
              noSpace:true
              //alphanumeric is the custom method, we defined in the above
              
          },
          dist:{
            required:true
          },
          age: {
               required:true,
               number:true,
               agevalid:true,
               aglid:true
                },
          pncode:{
              required: true,
              number: true,
              pin:true,
              minlength: 6,
              maxlength: 6
            },
           phone:{
              required: true,
              number: true,
              phonenum:true,
              minlength: 10,
              maxlength: 10
            },
          image: {
              required: true,
              accept: "(pdf)"
          },
          email: {
              required: true,
              customEmail: true
          },
          pwd: {
              required: true,
              minlength:8
              
          },
          cpwd: {
              required: true,
              equalTo: '[name="pwd"]'
          }
          
         
         
      },
      messages:{
          fname: {
              //error message for the required field
              required: 'Please enter fullname!',
              alphabetsnspace: 'only alphabets and space allowed'
          },
          cname: {
              //error message for the required field
              required: 'Please enter cityname!',
              alphabetsnspace: 'only alphabets and space allowed'
          },
           hname: {
              //error message for the required field
              required: 'Please enter housename!',
              alphabetsnspace: 'only alphabets and space allowed'
          },
          dist:{
            required:'Mandatory field!'
          },
          age:{
              required:'Mandatory field!',
              number: 'Please enter only numbers',
              agevalid:'Age must be greater than 18'
          },
           pncode:{
              required: 'Mandatory field!',
              number: 'Please enter only numbers',
              minlength: 'Please enter 6 digits'
            },
          phone:{
              required: 'Mandatory field!',
              number: 'Please enter only numbers',
              phonenum: 'The number must start with 6/7/8/9',
              minlength: 'Please enter 10 digits'
              
            },
          image: {
              required: 'Please select pdf!'
          },
          email: {
              required: 'Please enter email!',
              //error message for the email field
              email: 'Please enter valid email!'
          },
          pwd: {
              required: 'Please enter password!',
              minlength:'Please enter atleast 8 length password'
          },
          cpwd: {
              required: 'Please enter confirm password!',
              equalTo: 'Please enter same password!'
          }
          
          
      },
      
      highlight: function (element) {
                $(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            }
  });
}

</script> 
</body>
</html>
