<?php
session_start();
if(isset($_SESSION['loginid'])){
include('dbconnect.php');
$id=$_SESSION['loginid'];
$mail=$_SESSION['mail'];
}
?>
<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Register | Adminpro - Admin Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
        ============================================ -->
    <link rel="shortcut icon" type="material-design/image/x-icon" href="img/favicon.ico">
    <!-- Google Fonts
        ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/bootstrap.min.css">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/font-awesome.min.css">
    <!-- adminpro icon CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/adminpro-custon-icon.css">
    <!-- meanmenu icon CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/meanmenu.min.css">
    <!-- mCustomScrollbar CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/jquery.mCustomScrollbar.min.css">
    <!-- animate CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/animate.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/normalize.css">
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/form.css">
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/style.css">
    <!-- responsive CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/responsive.css">
    <!-- modernizr JS
        ============================================ -->
    <script src="material-design/js/vendor/modernizr-2.8.3.min.js"></script>
    <style type="text/css">
    .error{
  color: #F00;
  background-color: #FFF;
    }
  </style>
</head>

<body class="materialdesign">
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- Header top area start-->
    <div class="wrapper-pro">
    
        <div class="content-inner-all">
            
            <!-- Header top area end-->
            <!-- Breadcome start-->
            
            <!-- Breadcome End-->
            <!-- Mobile Menu start -->
            <!-- Mobile Menu end -->
            <!-- Breadcome start-->
            
            <!-- Breadcome End-->
            <!-- welcome Project, sale area start-->
            <!-- Data table area End-->

            <!-- Breadcome End-->
            <!-- Register Start-->
<div class="login-form-area mg-t-30 mg-b-15">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3"></div>
                        <form action="#" id="reg" method="post" class="adminpro-form" enctype="multipart/form-data">
                            <div class="col-lg-6">
                                <div class="login-bg">
                                    <div class="row">
                                        <div class="col-lg-12">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>EmailId</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="text" name="email" value="<?php echo"$mail";?>" placeholder="Full name" readonly/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>New Password</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="password" name="pass" placeholder="password"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>Retype Password</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="password" name="rpass" placeholder="confirm password"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                            <div class="login-button-pro" align="center">
                                                <button type="submit" class="login-button login-button-lg" name="submit" id="submit">Change</button>
                                            </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                        
<?php
include "dbconnect.php";
   
if(isset($_POST['submit']))
{
$uname= $_POST["email"];
$new1= $_POST["pass"];
$new=md5($new1);
$conf=$_POST["rpass"];
$re= mysqli_query($con,"select * from login where email='$uname'");


if(mysqli_num_rows($re)>0)
{
  
  if ($new1==$conf)
  { 
  mysqli_query($con,"update login set password='$new' where email='$uname'");
  ?>
    <script>
    alert("successfully updated");
    </script>
    <?php
  }
  else
  {
    ?>
    <script>
    alert("Password MisMatch");
    </script>
  
<?php
  }
}
else
{
  
  ?>
    
    <script>
  alert("Password Does not exists");
  </script>    
    <?php }
}?>
                        <div class="col-lg-3"></div>
                    </div>
                </div>
            </div>
            <!-- Register End-->
        </div>
    </div>
    <!-- Footer Start-->
    
    <!-- Footer End-->
    <!-- jquery
        ============================================ -->
    <script src="material-design/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="material-design/js/bootstrap.min.js"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="material-design/js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="material-design/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="material-design/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="material-design/js/jquery.scrollUp.min.js"></script>
    <!-- form validate JS
        ============================================ -->
    <script src="material-design/js/jquery.form.min.js"></script>
    <script src="material-design/js/jquery.validate.min.js"></script>
    <script src="material-design/js/form-active.js"></script>
    <!-- main JS
        ============================================ -->
    <script src="material-design/js/main.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/3.3.1/jquery-ui.min.js" ></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
    jQuery.validator.addMethod("noSpace", function(value, element) { 
    return value == '' || value.trim().length != 0;  
}, "No space please and don't leave it empty");
jQuery.validator.addMethod("customEmail", function(value, element) { 
  return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test( value ); 
}, "Please enter valid email address!");

$.validator.addMethod("alphabetsnspace", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    });
$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, numbers, and underscores only please" );
var $userreg = $('#reg');
if($userreg.length){
  $userreg.validate({
    errorClass: 'errors',
      rules:{
          email: {
              required: true,
              customEmail: true
          },
          pass: {
              required: true,
              minlength:8
              
          },
          rpass: {
              required: true,
              equalTo: '[name="pass"]'
          }
      },
      messages:{
          email: {
              required: 'Please enter email!',
              //error message for the email field
              email: 'Please enter valid email!'
          },
          pass: {
              required: 'Please enter password!',
              minlength:'Please enter atleast 8 length password!'
          },
          rpass: {
              required: 'Please enter confirm password!',
              equalTo: 'Please enter same password!'
          },
         
          
          
      },
     highlight: function (element) {
                $(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            }
  });
}
  </script> 
</body>

</html>