<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
        #customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #cc0066;
  color: white;
}
    </style>
</head>
<body>
<table id="customers">
  <?php
    include 'dbconnect.php';
    echo "<th>ID</th><th>Full Name</th><th>Email-Id</th><th>House Name</th><th>City Name</th><th>Phone</th>" ;
    $query="SELECT * FROM `userrgstr_table`,`login` WHERE `userrgstr_table`.id=`login`.id and `login`.status='1'";
    $result = mysqli_query($con,$query) or die(mysqli_error());
    if ($result->num_rows > 0)
    {
      $i=1;
      while($row = $result->fetch_assoc()) 
      {
        echo "<tr><td style='text-align:center;'>".$i."</td><td>".$row["fname"]."</td><td>".$row["email"]."</td><td>".$row["hname"]."</td><td>".$row["cityname"]."</td><td>".$row["phone"]."</td>";?>
        </tr>
  <?php
        ++$i;
      }
    }
    else
    {
                        
    }
    $con->close();
  ?>
</table>
</body>
</html>