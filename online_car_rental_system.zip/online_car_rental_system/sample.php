<!DOCTYPE html>
<html>
<head>
<title></title>
<style type="text/css">
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #cc0066;
  color: white;
}
</style>
</head>
<body>
<table id="customers">
<?php
include 'dbconnect.php';
$se="select * from cardetails_table where status ='available'";
 $r=mysqli_query($con,$se);
?>
<tr>
<th>No</th><th>Car</th><th>Name</th><th>Amount</th><th>Status</th><th>Action</th>
</tr>
<?php
$i=1;
while($row=mysqli_fetch_array($r))  
{
?>
<tr>
<td>
    <?php
    echo $i;
    ?>
</td>
<td>
    <?php
   echo '<img src="data:image/jpeg;base64,'.base64_encode($row['pictures'] ).'" style="width:200px"/>';
   ?>
</td>
<td> 
   <?php 
      $dn=$row['carname'];
      $df=$row['model'];
      echo "$dn"."-"."$df";
   ?>
  </td>
  <td>
    <?php
    echo $row['price'];
    ?>
  </td>
  <td>
    <?php
    echo $row['status'];
    ?>
  </td>
  <td>
    <a href="view.php?id=<?php echo $row["cid"];?>"><input type='submit' name='submit' value='View' style="background-color: blue;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;">
    </a>
  </td>
<?php
++$i;
}
?>
</table>
<?php
include 'dbconnect.php';
$se1="select * from cardetails_table where status ='unavailable'";
 $r1=mysqli_query($con,$se1);
 if($r1->num_rows>0)
 {
?>
<table style="margin-top: 80px;" id="customers">
<thead>
  <tr style="text-align: center;">
    <th colspan="8" style="text-align: center;padding: 10px;">Blocked Cars</th>
  </tr>
</thead>
<tr>
<th>No</th><th>Car</th><th>Name</th><th>Amount</th><th>Status</th><th>Action</th>
</tr>
<?php
$i=1;
while($row1=mysqli_fetch_array($r1))  
{
?>
<tr>
<td>
    <?php
    echo $i;
    ?>
</td>
<td>
    <?php
   echo '<img src="data:image/jpeg;base64,'.base64_encode($row1['pictures'] ).'" style="width:200px"/>';
   ?>
</td>
<td> 
   <?php 
      $dn=$row1['carname'];
      $df=$row1['model'];
      echo "$dn"."-"."$df";
   ?>
  </td>
  <td>
    <?php
    echo $row1['price'];
    ?>
  </td>
  <td>
    <?php
    echo $row1['status'];
    ?>
  </td>
  <td>
    <a href="cunblock.php?id=<?php echo $row1["cid"];?>"><input type='submit' name='submit' value='Unblock' style="background-color: green;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;">
    </a>
  </td>
<?php
++$i;
}
}
?>
</body>
</html>