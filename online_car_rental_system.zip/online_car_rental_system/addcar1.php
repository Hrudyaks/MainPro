<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Register | Adminpro - Admin Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
        ============================================ -->
    <link rel="shortcut icon" type="material-design/image/x-icon" href="img/favicon.ico">
    <!-- Google Fonts
        ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/bootstrap.min.css">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/font-awesome.min.css">
    <!-- adminpro icon CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/adminpro-custon-icon.css">
    <!-- meanmenu icon CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/meanmenu.min.css">
    <!-- mCustomScrollbar CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/jquery.mCustomScrollbar.min.css">
    <!-- animate CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/animate.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/normalize.css">
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/form.css">
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/style.css">
    <!-- responsive CSS
        ============================================ -->
    <link rel="stylesheet" href="material-design/css/responsive.css">
    <!-- modernizr JS
        ============================================ -->
    <script src="material-design/js/vendor/modernizr-2.8.3.min.js"></script>
    <style type="text/css">
    .error{
  color: #F00;
  background-color: #FFF;
    }
  </style>
</head>

<body class="materialdesign">
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- Header top area start-->
    <div class="wrapper-pro">
        
        <div class="content-inner-all">
            
            <!-- Header top area end-->
            <!-- Breadcome start-->
            
            <!-- Breadcome End-->
            <!-- Mobile Menu start -->
            
            <!-- Mobile Menu end -->
            <!-- Breadcome start-->
          
            <!-- Breadcome End-->
            <!-- Register Start-->
<div class="login-form-area mg-t-30 mg-b-15">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3"></div>
                        <form action="#" id="reg" method="post" class="adminpro-form" enctype="multipart/form-data">
                            <div class="col-lg-6">
                                <div class="login-bg">
                                    <div class="row">
                                        <div class="col-lg-12">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>Model</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="text" name="model" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>Registration Number</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="text" name="regno" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>Name</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="text" name="cname" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>A/C</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <div style="margin-top: 14px">
                                                <input type="radio" name="ac" value="yes" checked="checked">Yes                              
                                                <input type="radio" name="ac" value="no">No
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>Fuel Type</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <select name="fuel" id="fuel" style="margin-top: 14px; padding-right: 150px;width: 100%;height: 35px;border: 1px solid #ccc;">
                                                <option value="">Select Fuel</option>
                                                <option value="petrol">Petrol</option>
                                                <option value="diesel">Diesel</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>Seats</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="text" name="seat" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>Mileage</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="text" name="mileage" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>Pictures</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="file" name="image" id="image" style="margin-top: 15px;padding-right: 100px;" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>Price</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="text" name="price" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                            <div class="login-button-pro" align="center">
                                                <button type="submit" class="login-button login-button-lg" name="submit" id="submit">Submit</button>
                                            </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <?php
include 'dbconnect.php'; 
            if(isset($_POST['submit']))
            {
        $model=$_POST['model'];
        $name=$_POST['cname'];
            $ac=$_POST['ac'];
            $fuel=$_POST['fuel'];
            $seat=$_POST['seat'];
            $mileage=$_POST['mileage'];
            $regno=$_POST['regno'];
            $fil=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
            $price=$_POST['price'];
                $sql="INSERT INTO `cardetails_table`(`model`, `regno`, `carname`, `seat`, `ac`, `fueltype`, `mileage`, `pictures`, `price`, `status`) VALUES ('$model','$regno','$name','$seat','$ac','$fuel','$mileage','$fil','$price','available')";
                $ch=mysqli_query($con,$sql);
                if($ch)
                {
                ?>
                <script>
                alert("Registered  Successfully");
                window.location="addcar1.php";
                </script>
                <?php
                }
                else
                {
                echo"<script>alert('Car already exists');</script>";
                }
            }
            mysqli_close($con);
            ?>
                        <div class="col-lg-3"></div>
                    </div>
                </div>
            </div>
            <!-- Register End-->
        </div>
    </div>
    <!-- Footer Start-->
    
    <!-- Footer End-->
    <!-- jquery
        ============================================ -->
    <script src="material-design/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="material-design/js/bootstrap.min.js"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="material-design/js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="material-design/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="material-design/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="material-design/js/jquery.scrollUp.min.js"></script>
    <!-- form validate JS
        ============================================ -->
    <script src="material-design/js/jquery.form.min.js"></script>
    <script src="material-design/js/jquery.validate.min.js"></script>
    <script src="material-design/js/form-active.js"></script>
    <!-- main JS
        ============================================ -->
    <script src="material-design/js/main.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/3.3.1/jquery-ui.min.js" ></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
    jQuery.validator.addMethod("noSpace", function(value, element) { 
    return value == '' || value.trim().length != 0;  
}, "No space please and don't leave it empty");
jQuery.validator.addMethod("customEmail", function(value, element) { 
  return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test( value ); 
}, "Please enter valid email address!");
jQuery.validator.addMethod("accept", function(value, element, param) {
     return value.match(new RegExp("." + param + "$"));
   },"Invalid Format");
$.validator.addMethod("alphabetsnspace", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    });
jQuery.validator.addMethod("seatnum", function(value, element) { 
  return this.optional( element ) || /^([1-9])+$/.test( value ); 
}, "Please enter valid seat number!");
jQuery.validator.addMethod("seatvalid", function(value, element) { 
  return value >= 4; 
}, "Please enter valid seat number!");
$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, numbers, and underscores only please" );
var $userreg = $('#reg');
if($userreg.length){
  $userreg.validate({
    errorClass: 'errors',
      rules:{
          //username is the name of the textbox
          model: {
              required: true,
              alphanumeric:true
          },
          regno: {
              required: true,
              alphanumeric:true,
              minlength: 9,
              maxlength: 9
          },
          cname: {
              required: true
          },
          ac: {
              required: true
          },
          fuel: {
               required:true
                },
          seat:{
              required: true,
              number: true,
              seatnum:true,
              seatvalid:true,
              minlength: 1,
              maxlength: 1
            },
           mileage:{
              required: true,
              number: true,
              minlength: 2,
              maxlength: 2
            },
          image: {
              required: true,
              accept: "(jpg?|jpeg|png)"
          },
          price: {
              required: true,
              number: true,
              minlength: 3,
              maxlength: 5
          } 
      },
      messages:{
          model: {
              //error message for the required field
              required: 'Please enter model!'
          },
          regno: {
              //error message for the required field
              required: 'Please enter registration number!'
          },
          cname: {
              //error message for the required field
              required: 'Please enter car name!'
          },
           ac: {
              //error message for the required field
              required: 'Please select an option!'
          },
          fuel:{
              required:'Mandatory field'
          },
           seat:{
              required: 'Mandatory field',
              number: 'Please enter only numbers'
            },
          mileage:{
              required: 'Mandatory field',
              number: 'Please enter only numbers'
            },
          
          image: {
              required: 'Please select picture!'
          },
          price: {
              required: 'Please enter price!',
              number: 'Please enter only numbers'
          }, 
      },
      
  highlight: function (element) {
                $(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            }
  });
}
  </script> 
</body>

</html>