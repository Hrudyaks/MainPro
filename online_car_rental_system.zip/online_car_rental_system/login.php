            <?php 
			session_start(); 
			include'dbconnect.php';
			if(isset($_POST['submit']))
			{
    		$email =$_POST['email'];
  			$npass =$_POST['password'];
        $pass =md5($npass);
			$sql="select * from login where email='$email'";
			$result=mysqli_query($con,$sql);
			$rowcount=mysqli_num_rows($result);
			if($rowcount!=0)
				{
				while($row=mysqli_fetch_array($result))
  					{
    				$dbu_email=$row['email'];
    				$dbu_pass=$row['password'];
    				$dbu_type=$row['type'];
            $dbu_status=$row['status'];
    				if($dbu_email==$email && $dbu_pass==$pass && $dbu_status=='1')
    					{
      					if($dbu_type==0) 
      						{
      							$_SESSION['loginid']=$row['id'];
      							$_SESSION['mail']=$row['email'];
          					header('Location:dashboardphp.php');
      						}
      					elseif($dbu_type==1)
      						{
        					$_SESSION['loginid']=$row['id'];
							    $_SESSION['mail']=$row['email'];
          					header('location:userhome.php');
      						}
                  elseif($dbu_type==2)
                  {
                  $_SESSION['loginid']=$row['id'];
                  $_SESSION['mail']=$row['email'];
                    header('location:driverhome.php');
                  }
    					}
    				else
        				{
                echo "<script>alert('Invalid emailid or password');</script>";        				}
  					}
				}
			else
				{
    		?>
    		<script>
    		alert("check username and password,if you have not registered yet signup");
    		</script>
    		<?php
  				}
 			}
			?>          
