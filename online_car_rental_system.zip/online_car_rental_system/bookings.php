<?php
session_start();
if(isset($_SESSION['loginid'])){
include('dbconnect.php');
$s=$_SESSION['loginid'];
}
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
<style type="text/css">
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #cc0066;
  color: white;
}
</style>
</head>
<body>
<table id="customers">
<?php
              include 'dbconnect.php';
              $qu="select * from driverregstr_table where id='$s'";
              $r=mysqli_query($con,$qu);
              while($row=mysqli_fetch_array($r))  
              {
                $did=$row['driverid'];
              $q1="select * from booking_table,driverregstr_table where booking_table.driverid='$did' and driverregstr_table.driverid='$did'";
              $s1=mysqli_query($con,$q1);
              $rowcount=mysqli_num_rows($s1);
              if($rowcount>0)
              {
              echo "<th>Slno</th><th>First Name</th><th>Date From</th><th>Date To</th><th>Car Name</th><th>Register Number</th>" ;
              $i=1;
              while($r1=mysqli_fetch_array($s1)){
                $di=$r1['driverid'];
                $df=$r1['dfrom'];
                $dt=$r1['dto'];
                $ci=$r1['cid'];
                $q2="select userrgstr_table.fname,carname,model,regno from userrgstr_table,booking_table,cardetails_table where booking_table.userid=userrgstr_table.userid and booking_table.cid=cardetails_table.cid and cardetails_table.cid='$ci'";
                $s2=mysqli_query($con,$q2);
                while($r2=mysqli_fetch_array($s2))
                {
                    $fn=$r2['fname'];
                    $cn=$r2['carname'];
                    $mo=$r2['model'];
                    $reg=$r2['regno'];
                }
                echo"<tr><td>$i</td><td>$fn</td><td>$df</td><td>$dt</td><td>$cn -".$mo."</td><td>$reg</td>"; 
                ++$i;  
                }  
          }
      else
      {
        echo "<b>No Bookings Found!!!</b>";
      }
  }
            ?>
</table>
</body>
</html>