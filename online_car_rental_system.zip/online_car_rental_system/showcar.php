<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Register | Adminpro - Admin Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
		============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="material-design/img/favicon.ico">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/bootstrap.min.css">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/font-awesome.min.css">
    <!-- adminpro icon CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/adminpro-custon-icon.css">
    <!-- meanmenu icon CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/meanmenu.min.css">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/jquery.mCustomScrollbar.min.css">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/material-design/css/animate.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/normalize.css">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/form.css">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/style.css">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="material-design/css/responsive.css">
    <!-- modernizr JS
		============================================ -->
    <script src="material-design/js/vendor/modernizr-2.8.3.min.js"></script>
    <style type="text/css">
        .error{
  color: #F00;
  background-color: #FFF;
        }
        th{
          background: green;
          padding-top: 20px;
          padding-bottom: 20px;
          padding-left: 50px;
          padding-right: 50px;
        }
        td{
          height: 70px;
          padding: 20px;
          padding-left: 10px;
          padding-right: 10px;
          background: #eaeae1;
        }
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 250px; /* Location of the box */
  left: 100px;
  right: 250px;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  position: relative;
  background-color: #fefefe;
  margin: auto;
  margin-left: 450px;
  padding: 100;
  border: 1px solid #888;
  width: 30%;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
  -webkit-animation-name: animatetop;
  -webkit-animation-duration: 0.4s;
  animation-name: animatetop;
  animation-duration: 0.4s
}

/* Add Animation */
@-webkit-keyframes animatetop {
  from {top:-300px; opacity:0} 
  to {top:0; opacity:1}
}

@keyframes animatetop {
  from {top:-300px; opacity:0}
  to {top:0; opacity:1}
}

/* The Close Button */
.close {
  color: white;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

.modal-header {
  padding: 2px 16px;
  background-color: #5cb85c;
  color: white;
}

.modal-body {padding: 2px 16px;
padding: 80px;
}

.modal-footer {
  padding: 2px 16px;
  background-color: #5cb85c;
  color: white;
}
</style>
</head>

<body class="materialdesign">
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- Header top area start-->
<div class="wrapper-pro">
        <div class="left-sidebar-pro">
            <nav id="sidebar">
                <div class="sidebar-header">
                    <a href="#"><img src="images/download.jpg" alt="" />
                    </a>
                    <h3>Admin</h3>
                </div>
                <div class="left-custom-menu-adp-wrap">
                    <ul class="nav navbar-nav left-sidebar-menu-pro">
                        </ul>
                </div>
            </nav>
        </div>
        <!-- Header top area start-->
        <div class="content-inner-all">
            <div class="header-top-area">
                <div class="fixed-header-top">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-1 col-md-6 col-sm-6 col-xs-12">
                                <a href="dashboardphp.php"><h4 style="color: white;">Back</h4></a>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Header top area end-->
            <!-- Breadcome start-->
            
            <!-- Breadcome End-->
            <!-- Mobile Menu start -->
            <div class="mobile-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="mobile-menu">
                                <nav id="dropdown">
                                    <ul class="mobile-menu-nav">
                                        <li><a data-toggle="collapse" data-target="#Charts" href="#">Home <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                            <ul class="collapse dropdown-header-top">
                                                <li><a href="dashboard.html">Dashboard v.1</a>
                                                </li>
                                                <li><a href="dashboard-2.html">Dashboard v.2</a>
                                                </li>
                                                <li><a href="analytics.html">Analytics</a>
                                                </li>
                                                <li><a href="widgets.html">Widgets</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a data-toggle="collapse" data-target="#Chartsmob" href="#">Charts <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                            <ul id="Chartsmob" class="collapse dropdown-header-top">
                                                <li><a href="bar-charts.html">Bar Charts</a>
                                                </li>
                                                <li><a href="line-charts.html">Line Charts</a>
                                                </li>
                                                <li><a href="area-charts.html">Area Charts</a>
                                                </li>
                                                <li><a href="rounded-chart.html">Rounded Charts</a>
                                                </li>
                                                <li><a href="c3.html">C3 Charts</a>
                                                </li>
                                                <li><a href="sparkline.html">Sparkline Charts</a>
                                                </li>
                                                <li><a href="peity.html">Peity Charts</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a data-toggle="collapse" data-target="#Tablesmob" href="#">Tables <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                            <ul id="Tablesmob" class="collapse dropdown-header-top">
                                                <li><a href="static-table.html">Static Table</a>
                                                </li>
                                                <li><a href="data-table.html">Data Table</a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>            <!-- Mobile Menu end -->
            <!-- Breadcome start-->
          
            <!-- Breadcome End-->
            <!-- Register Start-->
                    <div class="sparkline8-hd">
                                    <div class="main-sparkline8-hd">
                                        <h1>Car List</h1>
                                        <div class="sparkline8-outline-icon">
                                            <span class="sparkline8-collapse-link"><i class="fa fa-chevron-up"></i></span>
                                            <span><i class="fa fa-wrench"></i></span>
                                            <span class="sparkline8-collapse-close"><i class="fa fa-times"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="sparkline8-graph">
                                    <div class="datatable-dashv1-list custom-datatable-overright">
                                        <?php
include 'dbconnect.php';
$se="select * from cardetails_table";
 $r=mysqli_query($con,$se);
?>
<table  class="align-center" style="margin-top:100px;text-align:center;margin-left:auto;margin-right: auto;width: 80%;">
  
<tr style='color: black; font-size:15px;'>
  <th colspan="4" style="text-align: center;">No</th>
  <th style="text-align: center;padding-right: 30px;padding-left: 30px;">Car</th>
  <th colspan="7"style="text-align: center;">Details</th>
  <th style="text-align: center;">Status</th>
  <th style="text-align: center;">Action</th>
  </tr>
  <?php
while($row=mysqli_fetch_array($r))  
 {
?>
<tr>

<td style="font-size: 16px; text-align: center;" colspan="4">
    <?php
    echo $row['cid'];
    ?>
</td>
    <?php
   echo '  
                         
  <td>  
  <img src="data:image/jpeg;base64,'.base64_encode($row['pictures'] ).'"/>  
  </td>  
                          
  ';?>
<td style="font-size: 16px;width: 200px;padding-right: 150px;" colspan="7"> 
   <?php 
        echo"<b>Model : </b>";echo $row['model'];
        echo"<br>"; 
        echo"<b>Name : </b>";echo $row['carname'];
        echo"<br>";
        echo"<b>Seats : </b>";echo $row['seat'];
        echo"<br>";
        echo"<b>A/C : </b>";echo $row['ac'];
        echo"<br>";
        echo"<b>Registeration No : </b>";echo $row['regno'];
        echo"<br>";
        echo"<b>Fuel : </b>";echo $row['fueltype'];
        echo"<br>";
        echo"<b>Mileage : </b>";echo $row['mileage'];
        $cid=$row['cid'];
    ?>
  </td>
  <td style="padding-left: 50px;margin-left: 20px;">
    <?php
    echo $row['status'];
    ?>
  </td>
  <td>
    <button id="myBtn">Open Modal</button>
</td>
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <div class="modal-header">
      <span class="close">&times;</span>
      <h2>Comments</h2>
    </div>
    <div class="modal-body">
      <h3>Enter comments</h3>
      <br>
      <textarea name="comnts"><?php echo $cid;?></textarea>
      <input type="submit" name="submit">
    </div>
  </div>

</div>

<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
 </tr>
 
<?php
}
?>
</table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Register End-->
        </div>
    </div>
    <!-- Footer Start-->
    
    <!-- Footer End-->
    <!-- jquery
		============================================ -->
    <script src="material-design/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="material-design/js/bootstrap.min.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="material-design/js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="material-design/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="material-design/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="material-design/js/jquery.scrollUp.min.js"></script>
    <!-- form validate JS
		============================================ -->
    <script src="material-design/js/jquery.form.min.js"></script>
    <!--<script src="js/jquery.validate.min.js"></script>-->
    <script src="material-design/js/form-active.js"></script>
    <!-- main JS
		============================================ -->
    <script src="material-design/js/main.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/3.3.1/jquery-ui.min.js" ></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
    jQuery.validator.addMethod("noSpace", function(value, element) { 
    return value == '' || value.trim().length != 0;  
}, "No space please and don't leave it empty");
jQuery.validator.addMethod("customEmail", function(value, element) { 
  return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test( value ); 
}, "Please enter valid email address!");

$.validator.addMethod("alphabetsnspace", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    });
$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, numbers, and underscores only please" );
var $userreg = $('#reg');
if($userreg.length){
  $userreg.validate({
    errorClass: 'errors',
      rules:{
          //username is the name of the textbox
          model: {
              required: true,
              alphanumeric:true
          },
          name: {
              required: true
          },
          ac: {
              required: true
          },
          fuel: {
               required:true
                },
          seat:{
              required: true,
              number: true,
              minlength: 1,
              maxlength: 1
            },
           mileage:{
              required: true,
              number: true,
              minlength: 4,
              maxlength: 5
            },
          Pictures: {
              required: true
          } 
      },
      messages:{
          model: {
              //error message for the required field
              required: 'Please enter model!'
          },
          name: {
              //error message for the required field
              required: 'Please enter car name!'
          },
           ac: {
              //error message for the required field
              required: 'Please select an option!'
          },
          fuel:{
              required:'Mandatory field'
          },
           seat:{
              required: 'Mandatory field',
              number: 'Please enter only numbers'
            },
          mileage:{
              required: 'Mandatory field',
              number: 'Please enter only numbers'
            },
          
          mileage: {
              required: 'Please enter mileage!',
              //error message for the email field
              email: 'Please enter valid email!'
          },
          pictures: {
              required: 'Please select picture!'
          },  
      },
      
  highlight: function (element) {
                $(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            }
  });
}
$(document).ready(function(){
    $('#submit').click(function(){
        var image_name=$('#image').val();
        if(image_name=='')
        {
            alert("please select image");
            return false;
        }
        else
        {
            var extension=$('#image').val().split('.').pop().iolowerCase();
            if(jQuery.inArray(extension,['png','jpg','jpeg'])==-1)
            {
                alert('invalid image');
                $('$image').val('');
                return false;
            }
        }
    });
});
  </script> 
</body>

</html>