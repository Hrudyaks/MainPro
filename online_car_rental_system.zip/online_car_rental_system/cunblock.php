<?php 
include 'dbconnect.php';
$id = $_GET['id'];
if(isset($id))
{
  // Check record exists
  $query = "SELECT cid FROM `cardetails_table` WHERE cid='$id'";
  $result = mysqli_query($con,$query);
  if ($result->num_rows > 0)
  {
    while($r1=mysqli_fetch_array($result)){
     $id1=$r1['cid'];
     $query1 = "SELECT * FROM `cardetails_table` WHERE cid='$id1'";
     $result1 = mysqli_query($con,$query1);
     if($result1)
     {
      $del1 = "UPDATE cardetails_table SET status='available' WHERE cid= '$id1'";
      $res1=mysqli_query($con,$del1);
      if($res1)
      {
        echo '<script type="text/javascript">';
        echo 'alert("Car Blocked")';
        echo '</script>';
        echo "<script>setTimeout(\"location.href = '/online_car_rental_system/sample.php';\",50);</script>";
      }
     }     
    }
  }
}
?>